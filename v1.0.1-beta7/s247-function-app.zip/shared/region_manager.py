"""Per-region Storage Account lifecycle management with resource locks.

Provisions and deprovisions Storage Accounts per-region so Azure diagnostic
settings can stream logs to a same-region destination. Each storage account
gets an ``insights-logs`` container for blob-based log collection.
"""

import logging
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Set

from azure.identity import DefaultAzureCredential
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.resource import ResourceManagementClient
from azure.core.exceptions import ResourceNotFoundError
from shared.storage_names import regional_storage_name, tenant_storage_name

# ManagementLockClient may not be available in all azure-mgmt-resource versions
try:
    from azure.mgmt.resource.locks import ManagementLockClient
except ImportError:
    ManagementLockClient = None  # type: ignore[assignment,misc]

logger = logging.getLogger(__name__)

STORAGE_PREFIX = "s247diag"
LOGS_CONTAINER = "insights-logs"
LOCK_PREFIX = "s247-lock-sa"
# Dedicated, non-regional storage account for tenant-scoped logs (Entra ID).
# Tagged distinctly so BlobLogProcessor polls it but region reconciliation
# (which only considers ``diag-logs-regional``) never deprovisions it — giving
# a stable target the tenant admin can point an Entra diagnostic setting at.
TENANT_STORAGE_PURPOSE = "diag-logs-tenant"
# Default: don't delete storage accounts with blobs newer than this.
# Overridable via SAFE_DELETE_MAX_AGE_DAYS env var.
SAFE_DELETE_MAX_AGE_DAYS_DEFAULT = 7
# Lifecycle policy: blobs in insights-logs-* containers are deleted after this many
# days. The processor reads incrementally via block-list checkpoints and never
# deletes blobs itself, so retention is enforced here. Override via
# BLOB_RETENTION_DAYS env var.
BLOB_RETENTION_DAYS_DEFAULT = 7


def _get_blob_retention_days() -> int:
    """Return blob retention (lifecycle) days from env var or default."""
    import os
    try:
        return int(os.environ.get("BLOB_RETENTION_DAYS", BLOB_RETENTION_DAYS_DEFAULT))
    except (ValueError, TypeError):
        return BLOB_RETENTION_DAYS_DEFAULT


def _get_safe_delete_days() -> int:
    """Return safe-delete threshold from env var or default."""
    import os
    try:
        return int(os.environ.get("SAFE_DELETE_MAX_AGE_DAYS", SAFE_DELETE_MAX_AGE_DAYS_DEFAULT))
    except (ValueError, TypeError):
        return SAFE_DELETE_MAX_AGE_DAYS_DEFAULT


def _sanitize_region(region: str) -> str:
    """Remove non-alphanumeric characters and lowercase."""
    return re.sub(r"[^a-z0-9]", "", region.lower())


def _storage_account_name(region: str, suffix: str) -> str:
    """Build per-region storage account name.

    Azure storage account names: 3-24 chars, lowercase alphanumeric only.
    Format: s247diag{region}{suffix}  (e.g., s247diageastus<suffix>)
    """
    return regional_storage_name(region, suffix, os.environ.get("DIAG_SEED_REGION", ""))


def _tenant_storage_name(suffix: str) -> str:
    """Build the dedicated tenant-log storage account name.

    Format: s247diagtenant{suffix}  (<= 24 chars). One per deployment.
    """
    return tenant_storage_name(_sanitize_region(suffix))


def _check_storage_name(client, resource_group: str, name: str, region: str) -> None:
    """Fail before creation on unavailable names or unreadable ownership."""
    availability = client.storage_accounts.check_name_availability(
        {"name": name, "type": "Microsoft.Storage/storageAccounts"}
    )
    if availability.name_available is False:
        try:
            existing = client.storage_accounts.get_properties(resource_group, name)
        except ResourceNotFoundError as error:
            raise RuntimeError(
                f"Storage name '{name}' is unavailable globally. For a fresh install, "
                "choose another deploymentSuffix/DEPLOYMENT_SUFFIX; do not change a live collector's suffix."
            ) from error
        if (existing.tags or {}).get("managed-by") != "s247-diag-logs":
            raise RuntimeError(f"Storage account '{name}' is not owned by this collector")
        if _sanitize_region(existing.primary_location or "") != _sanitize_region(region):
            raise RuntimeError(f"Storage account '{name}' already exists in a different region")


class RegionManager:
    """Manage per-region Storage Accounts for diagnostic log collection."""

    def __init__(self, subscription_id: str):
        self.subscription_id = subscription_id
        self.credential = DefaultAzureCredential()

    # ------------------------------------------------------------------
    # Region analysis
    # ------------------------------------------------------------------

    @staticmethod
    def get_storage_name_for_region(region: str, suffix: str) -> str:
        """Return the storage account name for a given region."""
        return _storage_account_name(region, suffix)

    def get_active_regions(self, resources: List[Dict]) -> Set[str]:
        """Extract unique regions from a list of resources."""
        regions: Set[str] = set()
        for r in resources:
            location = r.get("location", "")
            if location:
                regions.add(location.lower())
        logger.info(f"Active regions: {regions}")
        return regions

    def get_provisioned_regions(self, resource_group: str,
                                suffix: Optional[str] = None) -> Dict[str, str]:
        """List per-region storage accounts in the RG.

        Returns a dict mapping region → storage account name.
        Identifies our accounts by the ``managed-by: s247-diag-logs`` tag.

        A failed earlier install can leave tagged accounts with another suffix
        in the same RG. When a region has several, this deployment's own name
        (from ``suffix``, default ``DIAG_STORAGE_SUFFIX``) wins; otherwise the
        choice is the lowest name so it never depends on listing order.
        """
        if suffix is None:
            suffix = os.environ.get("DIAG_STORAGE_SUFFIX", "")
        candidates: Dict[str, List[str]] = {}
        region_map: Dict[str, str] = {}
        try:
            client = StorageManagementClient(
                self.credential, self.subscription_id
            )
            for acct in client.storage_accounts.list_by_resource_group(resource_group):
                tags = acct.tags or {}
                if tags.get("managed-by") == "s247-diag-logs" and tags.get("purpose") == "diag-logs-regional":
                    if acct.primary_location:
                        candidates.setdefault(acct.primary_location.lower(), []).append(acct.name)
            for region, names in candidates.items():
                try:
                    own = _storage_account_name(region, suffix) if suffix else ""
                except ValueError:
                    own = ""
                region_map[region] = own if own in names else sorted(names)[0]
                if len(names) > 1:
                    logger.warning(
                        "Region %s has %d tagged diag storage accounts %s — using %s; "
                        "the others are likely left over from an earlier deployment",
                        region, len(names), sorted(names), region_map[region],
                    )
            logger.info(
                f"Provisioned diag storage accounts in '{resource_group}': {region_map}"
            )
        except Exception as e:
            logger.error(
                f"Failed to list storage accounts in '{resource_group}': {e}"
            )
        return region_map

    def get_subscription_name(self, subscription_id: str) -> str:
        """Resolve a subscription's display name (as shown in the Azure portal).

        Best-effort — returns "" if it can't be resolved (needs Reader on the
        subscription, which the managed identity has). The resource ID only
        carries the GUID, but the portal's diagnostic-settings dropdown lists
        subscriptions by name, so we surface the name for the operator.
        """
        try:
            from azure.mgmt.resource import SubscriptionClient
            sub_client = SubscriptionClient(self.credential)
            return sub_client.subscriptions.get(subscription_id).display_name or ""
        except Exception as e:
            logger.warning(f"Could not resolve subscription name for {subscription_id}: {e}")
            return ""

    def _resource_group_location(self, resource_group: str) -> str:
        """Return the location of the resource group (used to place the
        non-regional tenant SA somewhere sensible)."""
        try:
            rc = ResourceManagementClient(self.credential, self.subscription_id)
            return rc.resource_groups.get(resource_group).location
        except Exception as e:
            logger.error(f"Failed to get location of RG '{resource_group}': {e}")
            return "eastus"

    def get_tenant_storage_account(self, resource_group: str) -> Dict[str, str]:
        """Return the dedicated tenant-log storage account, or ``{}`` if none.

        Identified by the ``diag-logs-tenant`` tag (not a region), so it's
        immune to region reconciliation.
        """
        try:
            client = StorageManagementClient(self.credential, self.subscription_id)
            for acct in client.storage_accounts.list_by_resource_group(resource_group):
                tags = acct.tags or {}
                if tags.get("managed-by") == "s247-diag-logs" and \
                        tags.get("purpose") == TENANT_STORAGE_PURPOSE:
                    sa_id = (
                        f"/subscriptions/{self.subscription_id}/resourceGroups/{resource_group}"
                        f"/providers/Microsoft.Storage/storageAccounts/{acct.name}"
                    )
                    return {"region": acct.primary_location or "", "name": acct.name, "id": sa_id}
        except Exception as e:
            logger.error(f"Failed to list tenant storage account in '{resource_group}': {e}")
        return {}

    def ensure_tenant_storage_account(self, resource_group: str, suffix: str) -> Dict[str, str]:
        """Ensure the dedicated tenant-log storage account exists; return it.

        Idempotent — returns the existing account if present, otherwise creates
        one in the RG's location, tagged ``diag-logs-tenant`` (no region tag so
        region reconciliation leaves it alone), with the base insights-logs
        container, a resource lock, and the standard retention lifecycle policy.
        Returns ``{"region", "name", "id"}`` (id empty on create failure).
        """
        existing = self.get_tenant_storage_account(resource_group)
        if existing:
            return existing

        region = self._resource_group_location(resource_group)
        sa_name = _tenant_storage_name(suffix)
        result: Dict[str, str] = {"region": region, "name": sa_name, "id": ""}
        storage_client = StorageManagementClient(self.credential, self.subscription_id)

        try:
            _check_storage_name(storage_client, resource_group, sa_name, region)
            poller = storage_client.storage_accounts.begin_create(
                resource_group_name=resource_group,
                account_name=sa_name,
                parameters={
                    "location": region,
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                    "properties": {
                        "minimum_tls_version": "TLS1_2",
                        "allow_blob_public_access": False,
                    },
                    "tags": {
                        "managed-by": "s247-diag-logs",
                        "purpose": TENANT_STORAGE_PURPOSE,
                    },
                },
            )
            sa_resource = poller.result()
            result["id"] = sa_resource.id or ""
            logger.info(f"Created tenant storage account '{sa_name}' in {region}")
        except Exception as e:
            logger.error(f"Failed to create tenant storage account '{sa_name}': {e}")
            return result

        try:
            storage_client.blob_containers.create(
                resource_group_name=resource_group,
                account_name=sa_name,
                container_name=LOGS_CONTAINER,
                blob_container={},
            )
        except Exception as e:
            if "already exists" not in str(e).lower():
                logger.warning(f"Failed to create container in '{sa_name}': {e}")

        self.apply_lock(
            resource_group=resource_group,
            resource_name=sa_name,
            resource_type="Microsoft.Storage/storageAccounts",
        )
        self.apply_lifecycle_policy(
            storage_client=storage_client,
            resource_group=resource_group,
            sa_name=sa_name,
        )
        return result

    def deprovision_tenant_storage_account(self, resource_group: str) -> bool:
        """Delete the dedicated tenant SA when no Entra log type is enabled.

        Reuses ``deprovision_storage_account`` so the same safeguards apply —
        it skips deletion if the account still has recent (unprocessed) blobs,
        and restores the lock if the delete fails. No-op if the account doesn't
        exist. Returns True only if it was actually deleted.
        """
        existing = self.get_tenant_storage_account(resource_group)
        if not existing:
            return False
        return self.deprovision_storage_account(
            resource_group, existing.get("region", ""), existing["name"]
        )

    # ------------------------------------------------------------------
    # Provision / deprovision
    # ------------------------------------------------------------------

    def provision_storage_account(
        self, resource_group: str, region: str, suffix: str
    ) -> Dict:
        """Create a per-region Storage Account with an insights-logs container.

        Returns a dict with ``storage_account_name``, ``storage_account_id``,
        ``container_name``, and ``region``.
        """
        sa_name = _storage_account_name(region, suffix)
        result: Dict = {
            "storage_account_name": sa_name,
            "storage_account_id": "",
            "container_name": LOGS_CONTAINER,
            "region": region,
        }

        storage_client = StorageManagementClient(
            self.credential, self.subscription_id
        )

        # 1. Create storage account
        try:
            _check_storage_name(storage_client, resource_group, sa_name, region)
            poller = storage_client.storage_accounts.begin_create(
                resource_group_name=resource_group,
                account_name=sa_name,
                parameters={
                    "location": region,
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                    "properties": {
                        "minimum_tls_version": "TLS1_2",
                        "allow_blob_public_access": False,
                    },
                    "tags": {
                        "managed-by": "s247-diag-logs",
                        "purpose": "diag-logs-regional",
                        "region": region,
                    },
                },
            )
            sa_resource = poller.result()
            result["storage_account_id"] = sa_resource.id or ""
            logger.info(f"Created storage account '{sa_name}' in {region}")
        except Exception as e:
            logger.error(f"Failed to create storage account '{sa_name}': {e}")
            return result

        # 2. Create insights-logs container (diagnostic settings will create
        #    their own containers like insights-logs-{category}, but we
        #    ensure at least the base one exists for validation)
        try:
            storage_client.blob_containers.create(
                resource_group_name=resource_group,
                account_name=sa_name,
                container_name=LOGS_CONTAINER,
                blob_container={},
            )
            logger.info(f"Created container '{LOGS_CONTAINER}' in '{sa_name}'")
        except Exception as e:
            # Container may already exist — that's fine
            if "already exists" in str(e).lower() or "Conflict" in str(type(e).__name__):
                logger.debug(f"Container '{LOGS_CONTAINER}' already exists in '{sa_name}'")
            else:
                logger.warning(f"Failed to create container in '{sa_name}': {e}")

        # 3. Apply resource lock
        self.apply_lock(
            resource_group=resource_group,
            resource_name=sa_name,
            resource_type="Microsoft.Storage/storageAccounts",
        )

        # 4. Apply lifecycle (management) policy: delete blobs in insights-logs-*
        #    after BLOB_RETENTION_DAYS. The function reads blobs incrementally via
        #    block-list checkpoints and never deletes them itself, so this rule is
        #    the sole retention mechanism.
        self.apply_lifecycle_policy(
            storage_client=storage_client,
            resource_group=resource_group,
            sa_name=sa_name,
        )

        return result

    def apply_lifecycle_policy(
        self,
        storage_client: StorageManagementClient,
        resource_group: str,
        sa_name: str,
        retention_days: int = None,
    ) -> bool:
        """Apply a delete-after-N-days lifecycle rule to ``insights-logs-*`` containers.

        Best-effort: returns False on failure but never raises. Idempotent —
        ``create_or_update`` overwrites any prior policy with the same name.
        """
        days = retention_days if retention_days is not None else _get_blob_retention_days()
        policy = {
            "policy": {
                "rules": [
                    {
                        "name": "s247-diag-logs-retention",
                        "enabled": True,
                        "type": "Lifecycle",
                        "definition": {
                            "filters": {
                                "blobTypes": ["appendBlob", "blockBlob"],
                                "prefixMatch": ["insights-logs-"],
                            },
                            "actions": {
                                "baseBlob": {
                                    "delete": {"daysAfterModificationGreaterThan": days}
                                }
                            },
                        },
                    }
                ]
            }
        }
        try:
            storage_client.management_policies.create_or_update(
                resource_group_name=resource_group,
                account_name=sa_name,
                management_policy_name="default",
                properties=policy,
            )
            logger.info(
                "Applied lifecycle policy (delete after %d days) on '%s'",
                days, sa_name,
            )
            return True
        except Exception as e:
            logger.warning(
                "Failed to apply lifecycle policy on '%s' (blobs will not auto-expire): %s",
                sa_name, e,
            )
            return False

    def deprovision_storage_account(
        self, resource_group: str, region: str, sa_name: str
    ) -> bool:
        """Remove lock and delete the per-region storage account.

        Checks for unprocessed blobs first. If any blob in an
        ``insights-logs-*`` container is newer than the configured
        ``SAFE_DELETE_MAX_AGE_DAYS`` (default 7), the deletion is skipped
        to avoid data loss.
        """
        safe_days = _get_safe_delete_days()
        storage_client = StorageManagementClient(
            self.credential, self.subscription_id
        )

        # Safety check: look for recent blobs before deleting
        if self._has_recent_blobs(resource_group, sa_name, storage_client, safe_days):
            logger.warning(
                "Storage account '%s' in %s has unprocessed blobs newer than "
                "%d days — skipping deletion to avoid data loss",
                sa_name, region, safe_days,
            )
            return False

        lock_nm = f"s247-lock-{_sanitize_region(sa_name)}"

        # Order:
        #   1. Remove lock so delete can proceed
        #   2. Attempt delete
        #   3. If delete fails, restore the lock so the SA isn't left
        #      unprotected with unprocessed logs inside it.
        self.remove_lock(resource_group, lock_nm)
        try:
            storage_client.storage_accounts.delete(
                resource_group_name=resource_group,
                account_name=sa_name,
            )
            logger.info(f"Deleted storage account '{sa_name}' in {region}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete storage account '{sa_name}': {e}")
            # Rollback: re-apply the lock so the SA is not left unprotected.
            try:
                self.apply_lock(
                    resource_group=resource_group,
                    resource_name=sa_name,
                    resource_type="Microsoft.Storage/storageAccounts",
                )
                logger.warning(
                    "Re-applied lock on '%s' after delete failure", sa_name
                )
            except Exception as relock_err:
                logger.error(
                    "Could not restore lock on '%s' after delete failure — "
                    "storage account is UNPROTECTED: %s",
                    sa_name, relock_err,
                )
            return False

    def _has_recent_blobs(
        self, resource_group: str, sa_name: str,
        storage_client: StorageManagementClient,
        safe_days: int = SAFE_DELETE_MAX_AGE_DAYS_DEFAULT,
    ) -> bool:
        """Check if a storage account has blobs newer than the safe-delete cutoff."""
        from azure.storage.blob import BlobServiceClient

        cutoff = datetime.now(timezone.utc) - timedelta(days=safe_days)
        try:
            keys = storage_client.storage_accounts.list_keys(resource_group, sa_name)
            acct_key = keys.keys[0].value
            conn_str = (
                f"DefaultEndpointsProtocol=https;AccountName={sa_name};"
                f"AccountKey={acct_key};EndpointSuffix=core.windows.net"
            )
            blob_service = BlobServiceClient.from_connection_string(conn_str)

            for container in blob_service.list_containers():
                cname = container["name"]
                if not cname.startswith("insights-logs"):
                    continue
                container_client = blob_service.get_container_client(cname)
                for blob in container_client.list_blobs():
                    if blob.last_modified and blob.last_modified > cutoff:
                        logger.debug(
                            "Found recent blob %s/%s (modified %s) in '%s'",
                            cname, blob.name, blob.last_modified, sa_name,
                        )
                        return True
            return False
        except Exception as e:
            # If we can't check, err on the side of caution
            logger.warning(
                "Failed to check blobs in '%s', assuming recent blobs exist: %s",
                sa_name, e,
            )
            return True

    # ------------------------------------------------------------------
    # Reconciliation
    # ------------------------------------------------------------------

    def reconcile_regions(
        self,
        resource_group: str,
        active_regions: Set[str],
        provisioned_map: Dict[str, str],
        suffix: str,
    ) -> Dict:
        """Add/remove per-region storage accounts to match active regions.

        Returns a summary dict with ``added``, ``removed``, and ``errors``.
        """
        provisioned_regions = set(provisioned_map.keys())
        to_add = active_regions - provisioned_regions
        to_remove = provisioned_regions - active_regions

        summary: Dict = {"added": [], "removed": [], "errors": []}

        for region in to_add:
            try:
                info = self.provision_storage_account(resource_group, region, suffix)
                summary["added"].append(info)
                logger.info(f"Provisioned storage account for region {region}")
            except Exception as e:
                summary["errors"].append({"region": region, "error": str(e)})
                logger.error(f"Error provisioning storage for region {region}: {e}")

        for region in to_remove:
            sa_name = provisioned_map.get(region, "")
            if not sa_name:
                continue
            try:
                success = self.deprovision_storage_account(resource_group, region, sa_name)
                if success:
                    summary["removed"].append(region)
                else:
                    summary["errors"].append(
                        {"region": region, "error": "deprovision returned False"}
                    )
            except Exception as e:
                summary["errors"].append({"region": region, "error": str(e)})
                logger.error(f"Error deprovisioning storage for region {region}: {e}")

        logger.info(
            f"Reconciliation complete — added: {len(summary['added'])}, "
            f"removed: {len(summary['removed'])}, "
            f"errors: {len(summary['errors'])}"
        )
        return summary

    # ------------------------------------------------------------------
    # Resource locks
    # ------------------------------------------------------------------

    def apply_lock(
        self,
        resource_group: str,
        resource_name: str,
        resource_type: str,
    ) -> bool:
        """Apply a CanNotDelete management lock to a resource."""
        if ManagementLockClient is None:
            logger.warning("ManagementLockClient unavailable — skipping lock")
            return False
        lock_client = ManagementLockClient(
            self.credential, self.subscription_id
        )
        parts = resource_type.split("/", 1)
        if len(parts) != 2:
            logger.error(f"Invalid resource_type format: {resource_type}")
            return False

        provider_namespace = parts[0]
        resource_type_short = parts[1]
        lock_nm = f"s247-lock-{_sanitize_region(resource_name)}"

        try:
            lock_client.management_locks.create_or_update_at_resource_level(
                resource_group_name=resource_group,
                resource_provider_namespace=provider_namespace,
                parent_resource_path="",
                resource_type=resource_type_short,
                resource_name=resource_name,
                lock_name=lock_nm,
                parameters={
                    "level": "CanNotDelete",
                    "notes": "Managed by s247-diag-logs — do not remove manually.",
                },
            )
            logger.info(f"Applied lock '{lock_nm}' on {resource_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to apply lock on {resource_name}: {e}")
            return False

    def remove_lock(self, resource_group: str, lock_name: str) -> bool:
        """Remove a management lock by name from a resource group."""
        if ManagementLockClient is None:
            logger.warning("ManagementLockClient unavailable — skipping lock removal")
            return False
        lock_client = ManagementLockClient(
            self.credential, self.subscription_id
        )
        try:
            lock_client.management_locks.delete_at_resource_group_level(
                resource_group_name=resource_group,
                lock_name=lock_name,
            )
            logger.info(f"Removed lock '{lock_name}' from RG '{resource_group}'")
            return True
        except Exception as e:
            if "NotFound" in str(type(e).__name__) or "not found" in str(e).lower():
                logger.debug(f"Lock '{lock_name}' not found — nothing to remove")
                return True
            logger.error(f"Failed to remove lock '{lock_name}': {e}")
            return False
